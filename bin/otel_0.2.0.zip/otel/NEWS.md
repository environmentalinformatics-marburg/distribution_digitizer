# otel 0.2.0

* Zero Code Instrumentation (ZCI) works again (#20).

* The interpolation of R expressions in log messages is not supported
  any more (#21).

# otel 0.1.0

First release on CRAN.
